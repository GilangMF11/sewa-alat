  <!-- Main Footer -->
  <footer class="main-footer text-center">
    <strong>Sistem Rental Alat Jawa | Copyright &copy; 2025</strong>
    
  </footer>
</div>