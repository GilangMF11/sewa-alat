  <!-- Main Footer -->
  <footer class="main-footer text-center">
    <strong>Sistem Rental Alat | Copyright &copy; 2024</strong>
    
  </footer>
</div>